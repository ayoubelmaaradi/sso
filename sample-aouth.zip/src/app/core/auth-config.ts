import { AuthConfig } from 'angular-oauth2-oidc';

export const authConfig: AuthConfig = {
  issuer: 'https://sso-ppd.carrefour.com:443/openam/oauth2/preprod',
  clientId: 'openid_c4_sample_ppd', // The "Auth Code + PKCE" client
  dummyClientSecret: '0b1PUJ9_e5BZC3LbZpiU',
  responseType: 'code',
  redirectUri: window.location.origin + '/login/oauth2/code/oidc',
  silentRefreshRedirectUri: window.location.origin + '/',
  scope: 'openid profile email c4_sample_roles', // Ask offline_access to support refresh token refreshes
  useSilentRefresh: true, // Needed for Code Flow to suggest using iframe-based refreshes
  silentRefreshTimeout: 5000, // For faster testing
  timeoutFactor: 0.25, // For faster testing
  sessionChecksEnabled: true,
  showDebugInformation: true, // Also requires enabling "Verbose" level in devtools
  clearHashAfterLogin: false, // https://github.com/manfredsteyer/angular-oauth2-oidc/issues/457#issuecomment-431807040,
  nonceStateSeparator : 'semicolon',
  skipSubjectCheck: true,
  skipIssuerCheck: true,
  strictDiscoveryDocumentValidation: false,
  // jwks: false
  // Real semicolon gets mangled by IdentityServer's URI encoding
};
