const PROXY_CONFIG = [
  {
    context: [
      "/oauth2",
      "/connect/jwk_uri",
      "/endpoints",
      "/i",
      "/need",
      "/to",
      "/proxy"
    ],
    target: "https://sso-ppd.carrefour.com:443/openam/oauth2/preprod",
    secure: false,
    changeOrigin: true,
    pathRewrite: {
      "/oauth2": "",
      "/connect/jwk_uri": "/connect/jwk_uri",
    }
  }
]

module.exports = PROXY_CONFIG;
